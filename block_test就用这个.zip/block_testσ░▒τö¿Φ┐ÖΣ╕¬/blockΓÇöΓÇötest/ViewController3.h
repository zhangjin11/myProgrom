//
//  ViewController3.h
//  block——test
//
//  Created by zj on 16/6/20.
//  Copyright © 2016年 zj. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^MyBlock2)(id data);
typedef void (^BLOCK)(id data0,id data1) ;
@interface ViewController3 : UIViewController

@property(nonatomic,copy)MyBlock2 BlockTest2;

+(void)paserCallBackTestWithBlock:(MyBlock2)myblock;

+(void)paserCallBackTestWithBlock0:(BLOCK)myblock00;

@end
