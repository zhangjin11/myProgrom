//
//  ViewController2.h
//  block——test
//
//  Created by zj on 16/6/17.
//  Copyright © 2016年 zj. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^myBlock)(id data);

@interface ViewController2 : UIViewController

@property(nonatomic,copy)myBlock ThisBlockTest;


@end
