//
//  ViewController3.m
//  block——test
//
//  Created by zj on 16/6/20.
//  Copyright © 2016年 zj. All rights reserved.
//

#import "ViewController3.h"

@interface ViewController3 ()
@property (weak, nonatomic) IBOutlet UITextField *mytext;

@end

@implementation ViewController3

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"3";
}
- (IBAction)confirmNoLines:(id)sender {
    
    NSString *str = self.mytext.text;
    self.BlockTest2(str);
    [self.navigationController popViewControllerAnimated:YES];
    
}
+(void)paserCallBackTestWithBlock:(MyBlock2)myblock
{
    myblock(@"zhangjin_test");
}
+(void)paserCallBackTestWithBlock0:(BLOCK)myblock00
{
    myblock00(@"123",@"345");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
