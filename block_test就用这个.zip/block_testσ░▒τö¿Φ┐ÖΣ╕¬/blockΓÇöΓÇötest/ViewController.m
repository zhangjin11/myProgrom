//
//  ViewController.m
//  block——test
//
//  Created by zj on 16/6/17.
//  Copyright © 2016年 zj. All rights reserved.
//

#import "ViewController.h"
#import "ViewController2.h"
#import "ViewController3.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *df;

@property(nonatomic,strong) ViewController3 *view3;
@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
 
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    

  
    
}
- (IBAction)gh:(id)sender {
    
    [self performSegueWithIdentifier:@"gotoview" sender:nil];
}
- (IBAction)DonotHaveTheLineStoryboard:(id)sender {
    
  //传一个参数
  [ViewController3 paserCallBackTestWithBlock:^(id data) {
      NSString *str =data;
      NSLog(@"%@",str);
  }];
    
   //传二个参数
    [ViewController3 paserCallBackTestWithBlock0:^(id data0, id data1) {
        NSLog(@"%@,%@",data0,data1);
    }];
    
    
    __typeof(self) weakself = self;
    
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController3 *vc = [storyboard instantiateViewControllerWithIdentifier:@"ViewController3"];
    vc.BlockTest2 = ^(id data)
    {
        weakself.df.text = data;
         NSLog(@"无线 = %@",data);
    };
    
    
    
    [self.navigationController pushViewController:vc animated:YES];
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
  
  if([segue.identifier isEqualToString:@"gotoview"])
   {
       ViewController2 *controller = segue.destinationViewController;
       controller.ThisBlockTest = ^(id data)
       {
           self.df.text = data;
           NSLog(@"有线 = %@",data);
       };
   }
    
}
@end
