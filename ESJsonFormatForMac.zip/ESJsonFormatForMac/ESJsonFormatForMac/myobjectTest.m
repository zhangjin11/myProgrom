//
//  myobjectTest.m
//  ESJsonFormatForMac
//
//  Created by 张进 on 2017/5/15.
//  Copyright © 2017年 ZX. All rights reserved.
//

#import "myobjectTest.h"

@implementation ESRootClass

+(NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [Data class]};
}

@end

@implementation Data

+(NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"childList" : [Childlist class]};
}

@end


@implementation Childlist

@end
