//
//  myobjectTest.h
//  ESJsonFormatForMac
//
//  Created by 张进 on 2017/5/15.
//  Copyright © 2017年 ZX. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Data,Childlist;
@interface ESRootClass : NSObject

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray<Data *> *data;

@property (nonatomic, assign) NSInteger code;

@end
@interface Data : NSObject

@property (nonatomic, strong) NSArray<Childlist *> *childList;

@property (nonatomic, copy) NSString *typeCode;

@property (nonatomic, copy) NSString *typeName;

@end

@interface Childlist : NSObject

@property (nonatomic, copy) NSString *typeCode;

@property (nonatomic, copy) NSString *pid;

@property (nonatomic, copy) NSString *id;

@property (nonatomic, copy) NSString *typeDetail;

@property (nonatomic, copy) NSString *typeName;

@property (nonatomic, copy) NSString *riskGrade;

@property (nonatomic, assign) CGFloat typePoint;

@property (nonatomic, assign) NSInteger nseq;

@end


