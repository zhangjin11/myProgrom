
#import "ViewController.h"
#import "XHStarView.h"
#import "XHStarScoreView.h"

@interface ViewController ()
@property (nonatomic, weak) XHStarView *star;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 初始化后 已经根据星星的宽高和margin 计算出了scoreView 的size
    // 如果调整位置，只需要改变X 和Y 值即可
    XHStarScoreView *scoreView = [XHStarScoreView starScoreViewWithSingleStarWH:15 starMargin:3 starCount:5  addedTo:self.view];
    scoreView.maxScore = 100;
    scoreView.score = 50;
    scoreView.isAllowTouch = YES;
//    scoreView.fillColor = [UIColor blueColor];
//    scoreView.lineColor = [UIColor redColor];

    
    CGRect rect = scoreView.frame;
    rect.origin.y = 100;
    scoreView.frame = rect;
    
    
    UILabel *scoreLabel = [[UILabel alloc] init];
    [self.view addSubview:scoreLabel];
    scoreLabel.frame = CGRectMake(0, 300, 100, 30);
    scoreLabel.textColor = [UIColor blackColor];
    scoreLabel.text = [NSString stringWithFormat:@"%.1f",scoreView.score];
    scoreLabel.textAlignment = NSTextAlignmentCenter;
    
    scoreView.scoreBlock = ^(CGFloat score){
        scoreLabel.text = [NSString stringWithFormat:@"%.1f",score];
    };

    
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
//    self.star.percent = 0.8;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
